var express = require('express');
var http = require('http');
var path = require('path');
var fs = require('fs');
var expressLayouts = require('express-ejs-layouts');
var mysql = require('mysql');
var conn = require('connect');
var bodyParser = require('body-parser');
var session = require('express-session');
var multer = require('multer');

var app = express();
app.locals.pretty = true;

app.set('views',path.join(__dirname,'views'));

app.set('view engine','ejs');
app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static(path.join(__dirname)));

app.use(session({
  secret : 'my key',
  resave: true,
  saveUninitialized: true,
   cookie: {
    maxAge: 1000 * 60 * 60 // 쿠키 유효기간 1시간
  }
}));

var router = require('./routes/router');
app.use('/',router);

var sponser = require('./routes/sponser');
app.use('/sponser',sponser);

var admin = require('./routes/admin');
app.use('/admin',admin);

var seller = require('./routes/seller');
app.use('/seller',seller);



http.createServer(app).listen(3000,function(){
  console.log('서버연결');
});

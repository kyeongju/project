var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var conn = require('connect');
var multer = require('multer');
var path = require('path');

var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, './images/');
  },
  filename: function (req, file, callback) {
    var ext = path.extname(file.originalname);
    var filename = path.basename(file.originalname, ext);

    callback(null, filename + ext);
  }
});

var upload = multer({storage: storage});

conn = mysql.createConnection({
  host:'localhost',
  user: 'root',
  password: '25232021n',
  database: 'marketdb'
});
conn.connect(function(err){
  if(!err){console.log("database is connected ...");}
  else{console.log("err");}
});

conn = mysql.createConnection({
  host:'localhost',
  user: 'root',
  password: '25232021n',
  database: 'marketdb'
});
conn.connect(function(err){
  if(!err){console.log("database is connected ...");}
  else{console.log("err");}
});



// 마켓 관리 메인페이지
router.get('/allow_market',function (req,res) {
    var sql = 'SELECT * FROM market';

    conn.query(sql, function (err ,result,fields) {
     if(err){
       console.log('executing query string is fail');
     }else{
       res.render('admin_allow_market',{user:req.session.user,result:result});
     }
   });
 });



// 마켓 관리 상세보기
 router.post('/allow_market_detail',function (req,res) {
     var query = req.body.market;
     console.log(query);
     var sql = 'SELECT * FROM market where ma_number=?';

     conn.query(sql, query, function (err ,result,fields) {
      if(err){
        console.log('executing query string is fail');}
      else{
        var sql2 = 'SELECT product.* FROM market INNER JOIN store ON market.ma_number=store.ma_number INNER JOIN product ON store.storeNumber=product.storeNumber where market.ma_number=?';
        conn.query(sql2, query, function (err ,rows,fields) {
         if(err){
           console.log('executing query string is fail');
         }else{
           res.render('admin_allow_market_detail',{user:req.session.user,result:result,rows:rows});
          }
        });
      }
    });
  });



// 마켓 등록/거절 처리
router.get('/market_start',function (req,res) {

  var allow = req.query.check;
  var what = req.query.what;
  console.log(allow);
  console.log(what);

  var no = "3";
  var ok = "2";

  if(what==2){
    var sql = 'UPDATE market set statesName = ? where ma_number= ?';
    var temp = [ok,allow];
    conn.query(sql, temp, function (err ,result,fields) {
      if(err){ console.log('executing query string is fail');}
      else{
        res.redirect('allow_market');
        }
      });
    }
    else{
      var sql = 'UPDATE market set statesName = ? where ma_number= ?';
      var temp = [no,allow];
      conn.query(sql, temp, function (err ,result,fields) {
        if(err){
          console.log('executing query string is fail');
        }else{
          res.redirect('allow_market');
        }
      });
    }
  });




// 기부대상 리스트
router.get('/dogroup',function (req,res) {

 var sql = 'SELECT * FROM doobject';

   conn.query(sql, function (err ,result,fields) {
      if(err){ console.log('executing query string is fail'); }
      else {
        res.render('admin_dogroup',{user:req.session.user,result:result});
    }
   });
});



// 기부대상 등록
router.get('/doobejct_registration',function (req,res) {

  var sql = 'SELECT * FROM doobject';

    conn.query(sql, function (err ,result,fields) {
      if(err){ console.log('executing query string is fail');}
      else{
        res.render('admin_doobejct_registration',{user:req.session.user});
     }
    });
  });



// 기부대상 등록 (저장)
router.post('/doobejct_registration_add',upload.any(),function (req,res) {

  var file = req.files[0];
  var do_targetName = req.body.do_targetName;
  var do_image = 'images/'+file.originalname;
  var groupName = req.body.groupName ;
  var do_age = req.body.do_age ;

  console.log(do_targetName);
  console.log(do_image);
  console.log(groupName);
  console.log(do_age);

  var sql = 'INSERT INTO doobject (do_targetName,groupName,do_image,do_age) VALUES (?,?,?,?)';
  var temp = [do_targetName,groupName,do_image,do_age];
  console.log(temp+"temp");
   conn.query(sql, temp, function (err ,result,fields) {
    if(err){ console.log('executing query string is fail');}
    else{
       res.redirect('/admin/dogroup');
       }
     });
 });


 router.get('/vipmember',function (req,res) {

  var sql = 'select * from point_w';

    conn.query(sql, function (err ,result,fields) {
       if(err){ console.log('executing query string is fail'); }
       else {
         res.render('admin_vipmember',{user:req.session.user,result:result});
     }
    });
 });


 // 기부대상 선정
 router.get('/insertvipmember',function (req,res) {
     var id = req.query.id;
    var E_point = req.query.E_point;
     var dateObj = new Date();
     var year = dateObj.getFullYear();
     var month = dateObj.getMonth()+1;

     var today = year + "-" + month;

     var sql = 'INSERT INTO vip_member_stats values (?,?,?)';
     var temp = [today,E_point,id];
     conn.query(sql,temp, function (err ,result,fields) {
      if(err){
        console.log('executing query string is fail');
        res.send('<script>alert("이미 우수회원 지정완료.");location.href="allow_market";</script>');
      }else{
          res.send('<script>alert("우수회원 지정완료");location.href="allow_market";</script>');
      }
    });
  });

module.exports = router;

var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var conn = require('connect');
var multer = require('multer');
var path = require('path');

var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, './images/');
  },
  filename: function (req, file, callback) {
    var ext = path.extname(file.originalname);
    var filename = path.basename(file.originalname, ext);

    callback(null, filename + ext);
  }
});

var upload = multer({storage: storage});

conn = mysql.createConnection({
  host:'localhost',
  user: 'root',
  password: '25232021n',
  database: 'marketdb'
});
conn.connect(function(err){
  if(!err){console.log("database is connected ...");}
  else{console.log("err");}
});





// 마켓 등록 페이지
router.get('/enroll_market',function (req,res) {
  var do_targetNumber = req.query.do_targetNumber;
  console.log(do_targetNumber+"등록할 마켓이름");
  var sql = 'SELECT * FROM doobject where do_targetNumber=?';

  conn.query(sql,do_targetNumber,function (err ,result,fields) {
    if(err){console.log('executing query string is fail');}
    else{
      console.log(result);
      res.render('sponser_market_registration',{user:req.session.user,result:result});
    }
  });
});

router.post('/upload',function (req,res) {

  var id = req.session.user.id;
  var target = req.body.target;
  var market_name = req.body.market_name ;
  //var market_start = req.body.market_start ;
  //var end = req.body.market_end ;
  var target_do = req.body.target_do ;
  //var ma_picture = req.body.ma_picture;
  var storeName = req.body.storeName;


var year = req.body.year;
var month = req.body.month;
var day = req.body.day;

var end_year = req.body.end_year;
var end_month = req.body.end_month;
var end_day = req.body.end_day;

var market_start = year+"-"+month+"-"+day;
var end = end_year+"-"+end_month+"-"+end_day;

  console.log(id);
  console.log(target);
  console.log(market_name);
  console.log(market_start);
  console.log(end);
  console.log(target_do);
  //console.log(ma_picture);

  var sql = 'SELECT do_targetNumber,do_image FROM doobject where do_targetName=?';

  conn.query(sql, target, function (err ,result,fields) {
   if(err){
     console.log('executing query string is fail');
   }else{

     var num = result[0].do_targetNumber;
     var do_image = result[0].do_image;

     console.log(id);
     console.log(num);
     console.log(market_name);
     console.log(market_start);
     console.log(end);
     console.log(target_do);
     console.log(do_image);

    var sql2 = 'INSERT INTO market (do_targetNumber,id,ma_name,ma_picture,ma_start,ma_end,target_do) VALUES (?,?,?,?,?,?,?)';
   var temp2 = [num,id,market_name,do_image,market_start,end,target_do];
   console.log(temp2+"temp");
   conn.query(sql2, temp2, function (err ,result) {
     if(err){
       console.log('executing query string is fail');

     }else{
       console.log(result.insertId+"마켓번호");
     var ma_number = result.insertId;
     var store_states = 2;

     var dateObj = new Date();
     var year = dateObj.getFullYear();
     var month = dateObj.getMonth()+1;
     var day = dateObj.getDate();
     var today = year + "-" + month + "-" + day;

     var sql3 = 'INSERT INTO store (id,ma_number,storeName,startDate,store_states) VALUES (?,?,?,?,?)';
    var temp3 = [id,ma_number,storeName,today,store_states];
    console.log(temp3+"temp");
    conn.query(sql3, temp3, function (err ,result) {
      if(err){
        console.log('executing query string is fail');

      }else{
        console.log("보낼 판매처 아이디"+result.insertId);

    res.redirect('sponser_market_product?storeNumber='+result.insertId);
         }
       });

     }
   });


};
});
});




router.get('/sponser_market_product',function (req,res) {

var storeNumber = req.query.storeNumber;

var sql = 'SELECT * FROM product where storeNumber=?';

conn.query(sql,storeNumber,function (err ,result,fields) {
if(err){
 console.log('executing query string is fail');
}else{
console.log(result);
 res.render('sponser_market_product',{user:req.session.user,result:result,storeNumber:storeNumber});
}
});


});

//기부반영퍼센트 승인
router.get('/allow_percente',function (req,res) {

var donatePercent = req.query.donatePercent;
console.log(donatePercent+"기부반영퍼센트");
var storeNumber = req.query.storeNumber;
console.log(storeNumber+"판매처이름");

var sql = 'UPDATE store set donatePercent=? where storeNumber=?';
var temp = [donatePercent,storeNumber];
conn.query(sql,temp,function (err ,result,fields) {
if(err){ console.log('executing query string is fail');}
else{
  console.log(result);
  res.redirect("/mypage_market");
}
});


});






router.get('/product_registration',function (req,res) {
  var storeNumber = req.query.storeNumber;
     res.render('sponser_product_registration',{user:req.session.user,storeNumber:storeNumber});
});




router.post('/product_upload',upload.any(),function (req,res) {
    var file = req.files[0];

    var category = req.body.cate_code;
    var product_name = req.body.product_name ;
    var product_image = 'images/'+file.originalname;
    var product_price = req.body.product_price ;
    var product_context = req.body.product_context ;
    var product_index = req.body.product_index ;
    var storeNumber = req.body.storeNumber;

    console.log(storeNumber);
    console.log(category);
    console.log(product_name);
    console.log(product_image);
    console.log(product_price);
    console.log(product_context);
    console.log(product_index);


  var sql = 'INSERT INTO product (cate_code,storeNumber,pro_name,pro_picture,pro_price,pro_info,quantity) VALUES (?,?,?,?,?,?,?)';
  var temp = [category,storeNumber,product_name,product_image,product_price,product_context,product_index];
  console.log(temp+"temp");
  conn.query(sql, temp, function (err ,result,fields) {
    if(err){
      console.log('executing query string is fail');
    }else{

    res.redirect('sponser_market_product?storeNumber='+storeNumber);
    //res.render('do_green',{user:req.session.user,result:result});
    }
  });
});





// 마켓 관리 (상세보기)
router.get('/admin_market',function (req,res) {
    //res.render('mypage',{user:req.session.user});
    var query = req.query.market;
    console.log(query);
    var sql = 'SELECT * FROM market where ma_number=?';

    conn.query(sql, query, function (err ,result,fields) {
     if(err){
       console.log('executing query string is fail');
     }else{

       //마켓 - 판매처 가져오기
       var sql2 = 'SELECT * FROM store WHERE ma_number=? '
       conn.query(sql2, query, function (err ,rows,fields) {
        if(err){
          console.log('executing query string is fail');
        }else{

          var sql3 = 'SELECT * FROM feed WHERE ma_number=?';


          conn.query(sql3, query, function (err ,row,fields) {
           if(err){
             console.log('executing query string is fail');
           }else{


          res.render('sponser_admin_market',{user:req.session.user,result:result,rows:rows,row:row});
        }
      });

     }
   });
  }
 });
});



//승인을 위한 물품 상세보기
router.get('/sponser_allow_store',function (req,res) {
  console.log("??");
    //res.render('mypage',{user:req.session.user});
    var storeNumber = req.query.storeNumber;
    var sql = 'SELECT * FROM product where storeNumber=?';
console.log(storeNumber+"dddd");
    conn.query(sql, storeNumber, function (err ,result,fields) {
     if(err){
       console.log('executing query string is fail');
     }else{
      // res.send({result:result});
      console.log(result+"물품");


       res.render('sponser_allow_store',{user:req.session.user,result:result});
    }
  });
});

router.get('/store_states',function (req,res) {

    var storeNumber = req.query.storeNumber;
    var ckeck = req.query.ckeck;

    var dateObj = new Date();
    var year = dateObj.getFullYear();
    var month = dateObj.getMonth()+1;
    var day = dateObj.getDate();
    var today = year + "-" + month + "-" + day;

    console.log(ckeck);
    if(ckeck=="ok"){
      //승인이라는 뜻
      var sales_states = "2";
      var temp = [sales_states,today,storeNumber];
      console.log(temp);
      var sql = 'UPDATE store SET store_states=?, startDate=? WHERE storeNumber=?';
      conn.query(sql, temp, function (err ,result,fields) {
       if(err){
         console.log('executing query string is fail');
       }else{
        // res.send({result:result});
        console.log(result+"물품");

        var sql = 'SELECT * FROM store WHERE storeNumber=?';
        conn.query(sql, storeNumber, function (err ,result,fields) {
         if(err){
           console.log('executing query string is fail');
         }else{
          // res.send({result:result});
          console.log(result[0].ma_number+"마켓번호");
          res.redirect('/sponser/admin_market?market='+result[0].ma_number);

        }
      });



      }
    });
  }
  else{
    //거절
    var sales_states = "1";
    var temp = [sales_states,storeNumber];
    var sql = 'UPDATE store SET store_states=? WHERE storeNumber=?';
    conn.query(sql, temp, function (err ,result,fields) {
     if(err){
       console.log('executing query string is fail');
     }else{
      // res.send({result:result});
      console.log(result+"물품");

      var sql = 'SELECT * FROM store WHERE storeNumber=?';
      conn.query(sql, storeNumber, function (err ,result,fields) {
       if(err){
         console.log('executing query string is fail');
       }else{
        // res.send({result:result});
        console.log(result[0].ma_number+"마켓번호");
        res.redirect('/sponser/admin_market?market='+result[0].ma_number);
      }
    });



    }
  });
};
});




//피드백 작성 페이지
router.get('/insertfeed',function (req,res) {

var ma_number = req.query.ma_number;
console.log(ma_number);


res.render('sponser_insertfeed',{user:req.session.user,ma_number:ma_number});
});


router.post('/insertfeed',upload.any(),function (req,res) {
    var file = req.files[0];

    var feed_title = req.body.feed_title;
    var donationReceipt = 'images/'+file.originalname;
    var feed_content = req.body.feed_content ;
    var ma_number = req.body.ma_number;

    console.log(feed_title);
    console.log(donationReceipt);
    console.log(feed_content);
    console.log(ma_number);


  var sql = 'INSERT INTO feed (feed_title,donationReceipt,feed_content,ma_number) VALUES (?,?,?,?)';
  var temp = [feed_title,donationReceipt,feed_content,ma_number];
  console.log(temp+"temp");
  conn.query(sql, temp, function (err ,result,fields) {
    if(err){
      console.log('executing query string is fail');
    }else{

    res.redirect('/sponser/admin_market?market='+ma_number);
    //res.render('do_green',{user:req.session.user,result:result});
    }
  });
});




module.exports = router;

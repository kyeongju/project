var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var conn = require('connect');
var multer = require('multer');
var path = require('path');

conn = mysql.createConnection({
  host:'localhost',
  user: 'root',
  password: '25232021n',
  database: 'marketdb'
});

conn.connect(function(err){
  if(!err){console.log("database is connected ...");}
  else{console.log("err");}
});

// 메인 페이지
router.get('/',function (req,res) {
  res.redirect('main');
});


router.get('/main',function (req,res) {
  if(req.session.user != null){
    var do_category="독거노인";
    var sql = "SELECT dogroup.*,doobject.*,market.* FROM dogroup INNER JOIN doobject ON dogroup.groupName=doobject.groupName INNER JOIN market ON doobject.do_targetNumber=market.do_targetNumber where dogroup.do_category=?";
    conn.query(sql,do_category,function(err,rows){
    if(rows.length>0){
      var sql1 = 'SELECT * FROM dogroup';
      conn.query(sql1,function (err,rows1) {
       if(err){
         console.log('기부 단체 불러오기 오류');
       }else{
           var sql2 = "SELECT dogroup.*,doobject.*,market.* FROM favorites INNER JOIN dogroup ON favorites.groupName=dogroup.groupName INNER JOIN doobject ON dogroup.groupName=doobject.groupName INNER JOIN market ON doobject.do_targetNumber=market.do_targetNumber where favorites.id=?";
           conn.query(sql2,req.session.user.id,function (err,rows2) {
            if(err){
              res.render('main',{user:req.session.user,rows:rows,rows1:rows1,rows2:null});
            }else{
              if(rows2.length>0){
                res.render('main',{user:req.session.user,rows:rows,rows1:rows1,rows2:rows2});
              }else{
                res.render('main',{user:req.session.user,rows:rows,rows1:rows1,rows2:null});
              }

           }
        });
      }
    });
  }else{
    var do_category="독거노인";
    var sql = "SELECT dogroup.*,doobject.*,market.* FROM dogroup INNER JOIN doobject ON dogroup.groupName=doobject.groupName INNER JOIN market ON doobject.do_targetNumber=market.do_targetNumber where dogroup.do_category=?";
    conn.query(sql,do_category,function(err,rows){
    var sql1 = 'select * from dogroup';
    conn.query(sql1,function(err,rows1){
      if(err){
        console.log('기부단체 불러오기 오류');
      }else{
        res.render('main',{user:req.session.user,rows:rows,rows1:rows1,rows2:null});
      }
    });
  });
  }
   });
  }else{
    var do_category="독거노인";
    var sql = "SELECT dogroup.*,doobject.*,market.* FROM dogroup INNER JOIN doobject ON dogroup.groupName=doobject.groupName INNER JOIN market ON doobject.do_targetNumber=market.do_targetNumber where dogroup.do_category=?";
    conn.query(sql,do_category,function(err,rows){
    var sql1 = 'select * from dogroup';
    conn.query(sql1,function(err,rows1){
      if(err){
        console.log('기부단체 불러오기 오류');
      }else{
        res.render('main',{user:req.session.user,rows:rows,rows1:rows1,rows2:null});
      }
    });
  });
  }
});

router.get('/favorites',function (req,res) {
  var id = req.session.user.id; // 아이디
  var groupName = req.query.groupName; //기부단체이름
  var sql = 'insert into favorites(id,groupName) values(?,?)';
  conn.query(sql,[id,groupName],function (err,rows) {
   if(err){
     console.log('즐겨찾기 추가 오류');
   }else{
    res.send('<script>alert("즐겨찾기 등록 완료!");location.href="/";</script>');
  }
});
}); //즐겨찾기 등록 버튼 클릭 시


// 로그인 기능
router.get('/login',function (req,res){
    res.render('login',{user:req.session.user});
});


// 로그인 확인
router.post('/login',function(req,res){
   var id = req.body.id ;
   var pw = req.body.pw ;
   var sql = "select * from member where id=? and pw=?"; //조건에 맞는 아이디와 패스워드 찾아옴

conn.query(sql,[id,pw],function(err,rows){
    if(rows.length > 0){
        req.session.user = {
          id : rows[0].id,
          name : rows[0].name,
          authorized : true
        }; //세션 저장
        req.session.save(function(){
        console.log(req.session.user.name+'로그인 성공!');

        // 관리자 모드
        if(req.session.user.id == "00"){ res.redirect('/admin/allow_market');}
        else{
          res.redirect('main');
         }
      });
    }else{ console.log('로그인 실패!');
      res.send('<script>alert("로그인 실패! 다시 로그인해주세요.");location.href="/login";</script>');
    }
   });
});


//로그아웃
router.get('/logout',function(req,res){
  console.log(req.session.user.name+'로그아웃!');
  req.session.destroy(function(){
   res.send('<script>alert("로그아웃 완료!");location.href="/login";</script>');
  });
});




//마이페이지.ejs 불러오기
router.get('/mypage', function (req, res) {
  res.render('mypage',{user:req.session.user});
});


// 마켓 메인페이지 (독거노인 초기화)
// router.get('/market',function(req,res){
//   var do_category="독거노인";
//   var sql = "SELECT dogroup.*,doobject.*,market.* FROM dogroup INNER JOIN doobject ON dogroup.groupName=doobject.groupName INNER JOIN market ON doobject.do_targetNumber=market.do_targetNumber where dogroup.do_category=?";
//   conn.query(sql,do_category,function(err,rows){
//   if(rows.length>0){
//     res.render('market_cate',{user:req.session.user,rows:rows});
//     }
//     else{
//       res.render('market_cate',{user:req.session.user,rows:rows});
//     }
//   });
// });

// 주최자 메인 페이지 (해외아동)
router.get('/Overseaschildren',function (req,res) {
  var temp = "해외아동";
  var sql = 'SELECT doobject.*,dogroup.* FROM dogroup INNER JOIN doobject ON doobject.groupName=dogroup.groupName where do_category=?';

  conn.query(sql,temp,function (err ,result,fields) {
   if(err){console.log('executing query string is fail');}
   else{

     res.render('mainOverseaschildren',{user:req.session.user,result:result});

}
});
});

// 기초수급
router.get('/Basicsupply',function (req,res) {
  var temp = "기초수급";
  var sql = 'SELECT doobject.*,dogroup.* FROM dogroup INNER JOIN doobject ON doobject.groupName=dogroup.groupName where do_category=?';

  conn.query(sql,temp,function (err ,result,fields) {
   if(err){console.log('executing query string is fail');}
   else{ res.render('mainBasicsupply',{user:req.session.user,result:result});
   }
  });
});

// 독거노인
router.get('/Aloneold',function (req,res) {
  var temp = "독거노인";
  var sql = 'SELECT doobject.*,dogroup.* FROM dogroup INNER JOIN doobject ON doobject.groupName=dogroup.groupName where do_category=?';

  conn.query(sql,temp,function (err ,result,fields) {
   if(err){console.log('executing query string is fail');}
   else{ res.render('mainAloneold',{user:req.session.user,result:result});
   }
  });
});

// 결핵아동
router.get('/Tuberculosis',function (req,res) {
  var temp = "결핵아동";
  var sql = 'SELECT doobject.*,dogroup.* FROM dogroup INNER JOIN doobject ON doobject.groupName=dogroup.groupName where do_category=?';

  conn.query(sql,temp,function (err ,result,fields) {
   if(err){console.log('executing query string is fail');}
   else{ res.render('mainTuberculosis',{user:req.session.user,result:result});
   }
  });
});

router.get('/market',function(req,res){
  var sql = "SELECT dogroup.*,doobject.*,market.* FROM dogroup INNER JOIN doobject ON dogroup.groupName=doobject.groupName INNER JOIN market ON doobject.do_targetNumber=market.do_targetNumber where dogroup.do_category='독거노인'";

  conn.query(sql,function(err,rows){
    //if(rows.length>0){
      res.render('market_cate',{user:req.session.user,rows:rows});
    //}
  });
}); //마켓.ejs 띄우기

router.get('/market_category',function(req,res){
  var do_category = req.query.do_category;
	var sql = "SELECT dogroup.*,doobject.*,market.* FROM dogroup INNER JOIN doobject ON dogroup.groupName=doobject.groupName INNER JOIN market ON doobject.do_targetNumber=market.do_targetNumber where dogroup.do_category=?";

  conn.query(sql,do_category,function(err,rows){
    if(rows.length>0){
      res.render('market_cate',{user:req.session.user,rows:rows});
    }
  });
}); //마켓-카테고리별 페이지.ejs 띄우기

router.get('/mkdetail', function (req, res) {
    var ma_number = req.query.ma_number; //마켓 번호
    var sql1 = "select * from store where ma_number=?"
    conn.query(sql1,ma_number,function(err,rows1){
      if(rows1.length>0){
        var sql = "SELECT store.*,product.*,market.* FROM market INNER JOIN store ON market.ma_number=store.ma_number INNER JOIN product ON store.storeNumber=product.storeNumber where market.ma_number=?";
        conn.query(sql,ma_number,function(err,rows2){
          if(rows2.length>0){
            res.render('mkdetail',{user:req.session.user,data1:rows1,data2:rows2});
          }
        });
      }
    });
}); //마켓 상세보기

router.get('/main_category',function(req,res){
  if(req.session.user != null){
    var do_category = req.query.do_category;
     var sql = "SELECT dogroup.*,doobject.*,market.* FROM dogroup INNER JOIN doobject ON dogroup.groupName=doobject.groupName INNER JOIN market ON doobject.do_targetNumber=market.do_targetNumber where dogroup.do_category=?";
    conn.query(sql,do_category,function(err,rows){
    if(rows.length>0){
      var sql1 = 'SELECT * FROM dogroup';
      conn.query(sql1,function (err,rows1) {
       if(err){
         console.log('기부 단체 불러오기 오류');
       }else{
         var sql2 = "SELECT dogroup.*,doobject.*,market.* FROM favorites INNER JOIN dogroup ON favorites.groupName=dogroup.groupName INNER JOIN doobject ON dogroup.groupName=doobject.groupName INNER JOIN market ON doobject.do_targetNumber=market.do_targetNumber where favorites.id=?";
         conn.query(sql2,req.session.user.id,function (err,rows2) {
            if(err){
              res.render('main',{user:req.session.user,rows:rows,rows1:rows1,rows2:null});
            }else{
              if(rows2.length>0){
                 res.render('main',{user:req.session.user,rows:rows,rows1:rows1,rows2:rows2});
               }else{
                 res.render('main',{user:req.session.user,rows:rows,rows1:rows1,rows2:null});
               }
           }
        });
      }
    });
    }
   });
  }else{
    var do_category = req.query.do_category;
     var sql = "SELECT dogroup.*,doobject.*,market.* FROM dogroup INNER JOIN doobject ON dogroup.groupName=doobject.groupName INNER JOIN market ON doobject.do_targetNumber=market.do_targetNumber where dogroup.do_category=?";
    conn.query(sql,do_category,function(err,rows){
    var sql1 = 'select * from dogroup';
    conn.query(sql1,function(err,rows1){
      if(err){
        console.log('기부단체 불러오기 오류');
      }else{
        res.render('main',{user:req.session.user,rows:rows,rows1:rows1,rows2:null});
      }
    });
  });
  }
}); //메인-카테고리별 페이지.ejs 띄우기


router.get('/pddetail', function (req, res) {
    var itemNumber = req.query.itemNumber; //물품 번호
    var sql = "SELECT store.*,product.*,market.* FROM market INNER JOIN store ON market.ma_number=store.ma_number INNER JOIN product ON store.storeNumber=product.storeNumber where product.itemNumber=?";
    conn.query(sql,itemNumber,function(err,rows){
      if(rows.length>0){
        res.render('pddetail',{user:req.session.user,data:rows});
      }
    });
}); //마켓 - 판매처 물품 상세보기

router.get('/pdpay', function (req, res) {
    var itemNumber = req.query.itemNumber; //물품 번호
    var dateObj = new Date();
    var year = dateObj.getFullYear();
    var month = dateObj.getMonth()+1;
    var day = dateObj.getDate();
    var today = year + "-" + month + "-" + day;
    var id = req.session.user.id; //구매자 아이디
    var x = req.query.pro_price; //판매 금액
    var point = x * 10 / 100; //포인트

    var sql1 = "select * from idshipping where id=?"
    conn.query(sql1,id,function(err,rows){
      if(rows.length>0){
        console.log('회원 배송지 검색 완료!');
        var shippingNumber = rows[0].shippingNumber;
        var payment = 1;
        var sql2 = "insert into ordertable(id,shippingNumber,orderDate,payment) values(?,?,?,?)";
        conn.query(sql2,[id,shippingNumber,today,payment],function(err,rows){
          if(!err){
            console.log('주문 입력 완료!');
            var sql3 = "SELECT ordertable.* FROM ordertable INNER JOIN idshipping ON ordertable.shippingNumber=idshipping.shippingNumber where ordertable.id=?";
            conn.query(sql3,id,function(err,rows){
              if(!err){
                console.log('주문번호 검색 완료!');
                var orderNumber = rows[rows.length-1].orderNumber;
                var shippingNumber = rows[0].shippingNumber;
                var orderQuantity = 1;
                var sql4 = "insert into goodsorder(orderNumber,itemNumber,orderQuantity) values(?,?,?)";
                conn.query(sql4,[orderNumber,itemNumber,orderQuantity],function(err,rows){
                  if(!err){
                    console.log('상품 주문 입력 완료!');
                    var point_states = 1;
                    var sql5 = "insert into point(id,orderNumber,occ_date,E_point,point_states) values(?,?,?,?,?)";
                    conn.query(sql5,[id,orderNumber,today,point,point_states],function(err,rows){
                      if(!err){
                        console.log('포인트 입력 완료!');
                        var sql6 = "update product set sales_states=0 where itemNumber=?"
                        conn.query(sql6,itemNumber,function(err){
                          if(!err){
                            console.log('물품 상태 수정 완료!');
                            res.send('<script>alert("상품 주문 완료!");location.href="/orderlist";</script>');
                          }
                        });
                      }
                    });
                  }
                });
              }
            });
          }
        });
      }
    });
}); //마켓 - 판매처 물품 상세보기 - 구매하기

// 마켓 상세보기
router.post('/mkdetail', function (req, res) {
    var mkNum = req.body.mkNum; //마켓 번호
    var sql = "select * from market where ma_number=?";
    conn.query(sql,mkNum,function(err,rows){
      if(rows.length>0){
        res.render('mkdetail',{user:req.session.user,data:rows});
      }
    });
}); //마켓 상세보기




router.get('/orderlist', function (req, res) {
    var id = req.session.user.id; //구매자 아이디
    var sql = "SELECT ordertable.*,goodsorder.*,product.* FROM ordertable INNER JOIN goodsorder ON ordertable.orderNumber=goodsorder.orderNumber INNER JOIN product ON goodsorder.itemNumber=product.itemNumber where ordertable.id=?";

    conn.query(sql,id,function(err,rows){
      if(err){
        res.send('<script>alert("주문내역조회 오류!");location.href="mypage";</script>');
      }else{
        res.render('mypage_orderlist',{user:req.session.user,rows:rows});
      }
    });
}); //마이페이지 - 주문내역 조회



router.get('/pointhistory', function (req, res) {
    var id = req.session.user.id; //구매자 아이디
    var sql = "SELECT ordertable.*,point.* FROM ordertable INNER JOIN point ON ordertable.orderNumber=point.orderNumber where ordertable.id=?";

    conn.query(sql,id,function(err,rows){
      if(err){
        res.send('<script>alert("포인트이력 조회 오류!");location.href="mypage";</script>');
      }else{
        res.render('mypage_pointhistory',{user:req.session.user,rows:rows});
      }
    });
}); //마이페이지 - 포인트 이력 조회


router.get('/mypage_market',function (req,res) {
    //res.render('mypage',{user:req.session.user});
    var id = req.session.user.id;
    console.log(id);
    var sql = 'SELECT * FROM market where id=?';

    conn.query(sql, id, function (err ,result,fields) {
     if(err){
       console.log('executing query string is fail');
     }else{
      // res.send({result:result});
       res.render('mypage_market',{user:req.session.user,result:result});
    }
  });
});



router.get('/pdmanager', function (req, res) {
  var id = req.session.user.id; //아이디
  var sql = "SELECT store.*,market.* FROM store INNER JOIN market ON market.ma_number=store.ma_number where store.id=?"; //판매처랑 마켓 조인
  conn.query(sql,id,function(err,rows){
    res.render('mypage_pdmanager',{user:req.session.user,rows:rows});
  });
});//판매처 관리.ejs 불러오기


module.exports = router;

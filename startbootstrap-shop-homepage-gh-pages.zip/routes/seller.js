var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var conn = require('connect');
var multer = require('multer');
var path = require('path');


var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, './images/');
  },
  filename: function (req, file, callback) {
    var ext = path.extname(file.originalname);
    var filename = path.basename(file.originalname, ext);

    callback(null, filename + ext);
  }
});

var upload = multer({storage: storage});

conn = mysql.createConnection({
  host:'localhost',
  user: 'root',
  password: '25232021n',
  database: 'marketdb'
});

conn.connect(function(err){
  if(!err){console.log("database is connected ...");}
  else{console.log("err");}
});

router.post('/stapply', function (req, res) {
    var ma_number = req.body.ma_number; //마켓번호
    var id = req.session.user.id; //아이디
    var datas = [id,ma_number];
    var sql = "insert into store (id,ma_number) values(?,?)";

    conn.query(sql,datas,function(err,rows){
        if(err){
          console.log('판매처 등록 실패!');
          console.log(err);
          res.send('<script>alert("판매처 등록 실패! 다시 등록해주세요.");location.href="main";</script>');
        }else{
          console.log('판매처 등록 완료!');
          var sql = "select storeNumber from store where ma_number=? and id=?";
          conn.query(sql,[ma_number,id],function(err,rows){
            if(rows.length>0){
              res.render('seller_insertpd',{user:req.session.user,rows:rows});
            }
          })
        }
    })
}); //판매처 등록

router.get('/insertpd', function (req, res) {
  var storeNumber = req.query.storeNumber; //판매처번호
  var id = req.session.user.id; //아이디
  var sql = "select * from store where storeNumber=? and id=?";
  conn.query(sql,[storeNumber,id],function(err,rows){
    if(rows.length>0){
      res.render('seller_insertpd',{user:req.session.user,rows:rows});
    }
  })
}); //물품 등록.ejs 불러오기


router.post('/uploadproduct',upload.any(),function (req, res) {
    var file = req.files[0];

    var storeNumber = req.body.storeNumber; //판매처 번호
    var cate_code = req.body.cate_code; //물품 카테고리
    var pro_picture = 'images/'+file.originalname; //물품 사진
    var pro_price = req.body.pro_price; //물품 가격
    var pro_name = req.body.pro_name; //물품 이름
    var pro_info = req.body.pro_info; //물품 설명
    var quantity = req.body.quantity; //물품 수량

    var datas = [cate_code,pro_picture,pro_price,pro_name,pro_info,quantity,storeNumber];
    var sql = "insert into product(cate_code,pro_picture,pro_price,pro_name,pro_info,quantity,storeNumber) values(?,?,?,?,?,?,?)";

    conn.query(sql,datas,function(err,rows){
      if(err){
        console.log('판매처 물품 등록 실패!');
        res.send('<script>alert("판매처 물품 등록 실패!");location.href="seller_insertpd";</script>');
      }else{
        console.log('판매처 물품 등록 완료!');
        var sql = "select * from product,store where store.storeNumber=? and product.storeNumber=?"
        conn.query(sql,[storeNumber,storeNumber],function(err,rows){
          res.render('seller_storepdlist',{user:req.session.user,rows:rows});
        })
      }
    })
}); //물품 등록

router.post('/storeregister',function (req, res) {
    var id = req.session.user.id; //아이디
    var donatePercent = req.body.donatePercent; //기부반영퍼센트
    var storeName = req.body.storeName; //판매처 이름
    var storeNumber = req.body.storeNumber; //판매처 번호
    var sql ="update store set donatePercent=?,storeName=? where storeNumber=? and id=?";

    conn.query(sql,[donatePercent,storeName,storeNumber,id],function(err,rows){
      if(err){
        console.log(err);
      }else{
        console.log("판매처 이름 및 기부퍼센트 등록완료!");
        var sql = "SELECT store.*,product.*,market.* FROM market INNER JOIN store ON market.ma_number=store.ma_number INNER JOIN product ON store.storeNumber=product.storeNumber where store.id=? and store.storeNumber=?";
        conn.query(sql,[id,storeNumber],function(err,rows){
          if(rows.length>0){
            res.render('seller_pdlist',{user:req.session.user,rows:rows});
          }
        });
      }
    });
}); //판매처 최종 등록




router.get('/pdlist', function (req, res) {
  var id = req.session.user.id; //판매자 아이디
  var ma_number = req.query.ma_number //마켓 번호

  var sql = "SELECT store.*,product.*,market.* FROM market INNER JOIN store ON market.ma_number=store.ma_number INNER JOIN product ON store.storeNumber=product.storeNumber where store.id=? and market.ma_number=?";
  conn.query(sql,[id,ma_number],function(err,rows){
    if(rows.length>0){
      res.render('seller_pdlist',{user:req.session.user,rows:rows});
    }
  });
}); //물품 등록한 목록.ejs 불러오기







module.exports = router;
